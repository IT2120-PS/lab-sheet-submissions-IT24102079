setwd("C:\\Users\\IT24102079\\Desktop\\Lab10")

##Question 1 
observed <-c(55,62,43,46,50)
prob <- c(.2, .2, .2, .2, .2)
chisq.test(x=observed, p=prob)

##Question 2
file_path <-"http://www.sthda.com/sthda/RDoc/data/housetasks.txt"
housetasks <- read.delim(file_path, row.names = 1)
housetasks

chisq <- chisq.test(housetasks)
chisq


##Exercise

observed <- c(120, 95, 85, 100)
chisq.test(x = observed, p = c(0.25, 0.25, 0.25, 0.25))









