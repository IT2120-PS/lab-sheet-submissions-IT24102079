setwd("C:\\Users\\IT24102079\\Desktop\\IT24102079-ps")
getwd()

#Q1

#i)Distribution of n = 50 and p = 0.85
pbinom(47,50,0.85,lower.tail = FALSE)
#we use false if the value is greater

#Q2
#i)Number of average calls receives per hour
#ii)Poisson Distribution
dpois(15,12)